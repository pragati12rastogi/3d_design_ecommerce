<?php require_once('header.php'); ?>

<?php
if(!isset($_REQUEST['id'])) {
	header('location: logout.php');
	exit;
} else {
	// Check the id is valid or not
	$statement = $pdo->prepare("SELECT * FROM tbl_product WHERE p_id=? ");
	$statement->execute(array($_REQUEST['id']));
	$total = $statement->rowCount();
	$result = $statement->fetchAll(PDO::FETCH_ASSOC);
	if( $total == 0 ) {
		header('location: logout.php');
		exit;
	}
}
?>
<div id="preloader" style="display:none" >
	<div id="status" style="display:none" ></div>
</div>
<section class="content-header">
	<div class="content-header-left">
		<h1>Edit Product</h1>
	</div>
	<div class="content-header-right">
		<a href="product.php" class="btn btn-primary btn-sm">View All</a>
	</div>
</section>

<?php
$statement = $pdo->prepare("SELECT t1.* FROM tbl_product t1 
LEFT JOIN tbl_top_category t2 on t2.tcat_id = t1.cat_id
LEFT JOIN tbl_mid_category t3 on t3.mcat_id = t1.subcat_id WHERE p_id=?");
$statement->execute(array($_REQUEST['id']));
$result = $statement->fetchAll(PDO::FETCH_ASSOC);
foreach ($result as $row) {
	$p_name = $row['p_name'];
	$p_old_price = $row['p_old_price'];
	$p_current_price = $row['p_current_price'];
	
	$p_featured_photo = $row['p_featured_photo'];
	$p_description = $row['p_description'];
	
	$p_feature = $row['p_feature'];
	
	$p_is_featured = $row['p_is_featured'];
	$p_is_active = $row['p_is_active'];

	$file_extension = $row['file_extension'];
	$p_sku = $row['p_sku'];
	$prod_model_file = $row['prod_model_file'];
    $youtube_prev = $row['youtube_prev'];
    $vimeo_prev = $row['vimeo_prev'];
    $p_tags = $row['p_tags'];
    $p_license = $row['p_license'];
    $p_custom_license = $row['p_custom_license'];
    $is_free = $row['is_free'];
	$tcat_id = $row['cat_id'];
    $mcat_id = $row['subcat_id'];
}

$product_photo_query = $pdo->prepare("SELECT * FROM tbl_product_photo WHERE p_id=?");
$product_photo_query->execute(array($_REQUEST['id']));
$product_photo = $product_photo_query->fetchAll(PDO::FETCH_ASSOC);


?>


<section class="content">

	<div class="row">
		<div class="col-md-12">

			<div class="alert alert-danger" id="alert-danger" style="display:none"></div>
			
			<div class="alert alert-success" id="alert-success" style="display:none"></div>
			
			<?php if(isset($_COOKIE['publishing_success'])){
				echo '<div class="alert alert-success" ><p>'.$_COOKIE['publishing_success'].'</p></div>';
			}?>	

			<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">

				<div class="box box-info">
					<div class="box-body">
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Category Name <span>*</span></label>
							<div class="col-sm-4">
								<select name="tcat_id" class="form-control select2 top-cat">
		                            <option value="">Select Category</option>
		                            <?php
		                            $statement = $pdo->prepare("SELECT * FROM tbl_top_category ORDER BY tcat_name ASC");
		                            $statement->execute();
		                            $result = $statement->fetchAll(PDO::FETCH_ASSOC);   
		                            foreach ($result as $row) {
		                                ?>
		                                <option value="<?php echo $row['tcat_id']; ?>" <?php if($row['tcat_id'] == $tcat_id){echo 'selected';} ?>><?php echo $row['tcat_name']; ?></option>
		                                <?php
		                            }
		                            ?>
		                        </select>
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Sub Category Name </label>
							<div class="col-sm-4">
								<select name="mcat_id" class="form-control select2 mid-cat">
		                            <option value="">Select Sub Category</option>
		                            <?php
		                            $statement = $pdo->prepare("SELECT * FROM tbl_mid_category WHERE tcat_id = ? ORDER BY mcat_name ASC");
		                            $statement->execute(array($tcat_id));
		                            $result = $statement->fetchAll(PDO::FETCH_ASSOC);   
		                            foreach ($result as $row) {
		                                ?>
		                                <option value="<?php echo $row['mcat_id']; ?>" <?php if($row['mcat_id'] == $mcat_id){echo 'selected';} ?>><?php echo $row['mcat_name']; ?></option>
		                                <?php
		                            }
		                            ?>
		                        </select>
							</div>
						</div>
						<?php if(file_exists('../public_files/uploads/model_product_files/'.$prod_model_file)){ ?>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Uploaded file </label>
							<div class="col-sm-4" style="padding-top:4px;">
								<a href="../public_files/uploads/model_product_files/<?php echo $prod_model_file; ?>" download> Click here to download file: <b><?php echo $prod_model_file; ?></b></a>
								<input type="hidden" name="old_prod_model_file" value="<?php echo $prod_model_file; ?>">
								<input type="hidden" name="old_file_extension" value="<?php echo $file_extension; ?>">
							</div>
						</div>
						<?php } ?>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Upload Your 3D model File <span>*</span><br><span style="font-size:12px;font-weight:normal;">( File Format in .zip Only )</span></label>
							<div class="col-sm-4" style="padding-top:4px;">
								<input type="file" name="prod_model_file[]" id="prod_model_file" class="image-uploader" multiple >
							</div>
							<div class="col-md-6 col-xs-offset-1">
								<span id="append_after_list" class="fa fa-spin fa-spinner" style="margin: 1% 45%; display:none"></span>
								<?php  
									$get_files_query = $pdo->prepare("SELECT * from temp_modal_files_upload where prod_id=?");
									$get_files_query->execute(array($_REQUEST['id']));
									$get_files = $get_files_query->fetchAll(PDO::FETCH_ASSOC);
									foreach( $get_files as $file_id => $files_details){ 
										echo '<div  class="prod_upload_files_old row mb_10 ">
											<div class="col-md-10 p_10">
												<p class="imageThumb m_0 "  title="'.$files_details['filename'].'">'. $files_details['filename'] .'</p>
											</div>
										<div class="col-md-2 center p_10"><button type="button" class="btn btn-danger btn-block btn-xs prev_remove" btn-id='. $files_details['id'] .' onclick="old_model_del(this)" >Delete</button></div></div>';
									}
								?>
							</div>
						</div>

						<div class="form-group">
							<label for="" class="col-sm-3 control-label">3D Model Name <span>*</span></label>
							<div class="col-sm-4">
								<input type="text" name="p_name" class="form-control" value="<?php echo $p_name; ?>">
							</div>
						</div>	
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">SKU No </label>
							<div class="col-sm-4">
								<input type="text" name="p_sku" class="form-control" value="<?php echo $p_sku; ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Old Price<br><span style="font-size:10px;font-weight:normal;">(In <?php echo ADMIN_CURRENCY_SYMBOL; ?>)</span></label>
							<div class="col-sm-4">
								<input type="text" name="p_old_price" id="p_old_price" class="form-control" value="<?php echo $p_old_price; ?>">
							</div>
						</div>	
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Current Price <span>*</span><br><span style="font-size:10px;font-weight:normal;">(In <?php echo ADMIN_CURRENCY_SYMBOL; ?>)</span></label>
							<div class="col-sm-4">
								<input type="text" name="p_current_price" id="p_current_price" class="form-control" value="<?php echo $p_current_price; ?>">
							</div>
							<div class="col-md-3">
								<label class="checkbox-inline" >
								<input type="checkbox" name="is_free" id="is_free" value="1" <?php echo ($is_free==1)?'checked':''; ?> style="height: 15px;width: 15px;" onclick="is_freebtnfn()">Share For Free</label> 
							</div>
						</div>	
						
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Embeds Youtube Link</label>
							<div class="col-sm-4" style="padding-top:4px;">
								<input name="youtube_prev" value="<?php echo $youtube_prev; ?>" type="text" class="form-control" placeholder="eg: https://youtube.com/watch?v=">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Embeds Vimeo Link</label>
							<div class="col-sm-4" style="padding-top:4px;">
								<input name="vimeo_prev" value="<?php echo $vimeo_prev; ?>" type="text" class="form-control" placeholder="eg: https://vimeo.com/">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Existing Featured Photo</label>
							<div class="col-sm-4" style="padding-top:4px;">
								<img src="../public_files/uploads/<?php echo $p_featured_photo; ?>" alt="" style="width:150px;">
								<input type="hidden" name="current_photo" value="<?php echo $p_featured_photo; ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Change Featured Photo </label>
							<div class="col-sm-4" style="padding-top:4px;">
								<input type="file" name="p_featured_photo">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Other Photos<br><span style="font-size:10px;font-weight:normal;">File Size: Max=5MB & Formats: jpg,png,jpeg,bmp</span></label>
							<div class="col-sm-4" style="padding-top:4px;">
								<div id="preview_images" style="padding-top: .5rem;"></div>
							</div>
							
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Description</label>
							<div class="col-sm-8">
								<textarea name="p_description" class="form-control ckeditor" cols="30" rows="10"><?php echo $p_description; ?></textarea>
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Tags <span>*</span> <sup class="fa fa-question-circle" data-toggle="tooltip" title="Add specific words that target your model, broad words which will generalize it and note its qualities or characteristics (like color, material, condition, etc). Do not add unrelated tags to your product." data-placement="top"></sup><br><span style="font-weight:100;font-size: small;">(Use comma(,) to seperate tags)</span> </label>
							<div class="col-sm-8">
								<input name="p_tags" data-role="tagsinput" id="p_tags" value="<?php echo $p_tags; ?>" class="form-control tag_input" type="text">
								<br>
								<div id="normally-hidden" class="form-control-static">
									
								</div>
							</div>

							
						</div>
						
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">License <span>*</span></label>
							<div class="col-sm-8">
								<select name="p_license" class="form-control" id="p_license" onchange="custom_license()" >
									<option value="royalty_free" <?php echo ($p_license == 'royalty_free')?'selected':''; ?> >Royalty Free</option>
									<option value="editorial" <?php echo ($p_license == 'editorial')?'selected':''; ?>>Editorial</option>
									<option value="custom" <?php echo ($p_license == 'custom')?'selected':''; ?>>Custom</option>
								</select>
							</div>
						</div>
						<div class="form-group" id="custom_license_div" style="display:none">
							<label for="" class="col-sm-3 control-label">Custom License <span>*</span></label>
							<div class="col-sm-8">
								<textarea name="p_custom_license" class="form-control" cols="30" rows="10" id="editor5"><?php echo $p_custom_license; ?></textarea>
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Is Featured?</label>
							<div class="col-sm-8">
								<select name="p_is_featured" class="form-control" style="width:auto;">
									<option value="0" <?php if($p_is_featured == '0'){echo 'selected';} ?>>No</option>
									<option value="1" <?php if($p_is_featured == '1'){echo 'selected';} ?>>Yes</option>
								</select> 
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-3 control-label">Is Active?</label>
							<div class="col-sm-8">
								<select name="p_is_active" class="form-control" style="width:auto;">
									<option value="0" <?php if($p_is_active == '0'){echo 'selected';} ?>>No</option>
									<option value="1" <?php if($p_is_active == '1'){echo 'selected';} ?>>Yes</option>
								</select> 
							</div>
						</div>

						<input type="hidden" name="product_id" value="<?php echo $_REQUEST['id']; ?>">
                                        
						<input type="hidden" name="deleted_photo" id="deleted_photo" >

						<div class="form-group">
							<label for="" class="col-sm-3 control-label"></label>
							<div class="col-sm-6">
								<button type="submit" class="btn btn-success pull-left" name="form1">Update</button>
							</div>
						</div>
					</div>
				</div>

			</form>


		</div>
	</div>

	<?php 
        foreach($product_photo as $ind => $photo_data){
            $preloaded[] = ['id'=>$photo_data['pp_id'],'src'=>'../public_files/uploads/product_photos/'.$photo_data["photo"]];
        }
        $preloaded_obj = json_encode($preloaded);        
    ?>

</section>
<script>

	document.addEventListener('DOMContentLoaded', function() {
		is_freebtnfn();
		custom_license();
		var tag_old_item = $('#p_tags').val();
		trigger_after_tag_add(tag_old_item);

		let preloaded = <?php echo $preloaded_obj; ?>;
		$('#preview_images').imageUploader({
            preloaded: preloaded,
            imagesInputName: 'photos',
            preloadedInputName: 'old'
        });
		$(".delete-image").on('click',function(){
            var photo_id = $(this).attr('data-id');
            if(photo_id != 0){
                var url = "product-other-photo-delete.php?id="+photo_id+"&id1=<?php echo $_REQUEST['id']; ?>";
                $.ajax({
                    url : url,
                    type : 'GET',
                    dataType: "json",
                    success: function(result){
                        if(result.status == 'success'){
							$("#alert-success").append('<p>'+result.msg+'</p>').show();
                        	setTimeout(function(){ $("#alert-success").hide(); }, 10000);
						}else{
							alert(result.msg);
							window.location.href= result.redirect;
						}
                    },
					error: function(jq,status,message) {
						
						alert('A jQuery error has occurred. Error:'+ jq.responseText);
					}
                })
            }    
        })

	}, false);

	function is_freebtnfn(){
		var chcekbox_selected = $("#is_free").prop("checked");
		if(chcekbox_selected){
			$("#p_old_price").val(0).css({"background": "lightgray","pointer-events": "none"});
			$("#p_current_price").val(0).css({"background": "lightgray","pointer-events": "none"});
		}else{
			$("#p_old_price").removeAttr("style");
			$("#p_current_price").removeAttr("style");
		}
	}

	function custom_license(){
		var license_val = $("#p_license").val();
		if(license_val == "custom"){
			$("#custom_license_div").show('slow');
		}else{
			$("#custom_license_div").hide('slow');
		}
		
	}
</script>
<link rel="stylesheet" href="../public_files/css/image-uploader.css">
<script src="../public_files/js/multiple-file-upload/prod_file_upload.js"></script>
<script src="../public_files/js/multiple-file-upload/prod_image_upload.js"></script>

<script>
    function old_model_del(selected_file){
        var model_file_id = selected_file.getAttribute("btn-id");
        $.ajax({
            url : 'ajax-function.php',
            type : 'GET',
            dataType: "json",
            data : {model_file_del:1,model_file_id:model_file_id},
            success: function(result){
                
                if(result.status == 'success'){
                    $(selected_file).parent().parent('.prod_upload_files_old').remove();
                }else{
                    alert(result);
                }
                
            }
        }) 
    }

    $('form').on('submit', function (event) {
        // Stop propagation
        event.preventDefault();
        event.stopPropagation();

        $("#alert-success").empty();
        $("#alert-danger").empty();
        
        var formData = new FormData(this);

        $uploaded_prodfile_path = $("input[name='uploaded_prodfile_path[]']");
        $uploaded_prodfile_name = $("input[name='uploaded_prodfile_name[]']");
        $uploaded_prodfile_type = $("input[name='uploaded_prodfile_type[]']");
        pathlength = $uploaded_prodfile_path.length;

        var prodfile_size = 0 
		       
        for( var ind =0; ind < pathlength;ind++){

            $file_path = $uploaded_prodfile_path[ind].defaultValue;
            $file_name = $uploaded_prodfile_name[ind].defaultValue;
            $file_type = $uploaded_prodfile_type[ind].defaultValue;

            var file_form = dataURLtoFile($file_path,$file_name);
            prodfile_size= prodfile_size+file_form.size;
            formData.append('temp_prod_model_file[]', file_form);
        }

        if(prodfile_size > 5368706371){
            $("#alert-danger").append('<p>Uploaded Model size cannot be greater than 5GB </p>').show();
            
            setTimeout(function(){ $("#alert-danger").hide(); }, 10000);
        }else{

            document.getElementById("preloader").style.display = 'block';
            document.getElementById("status").style.display = 'block';

            
            $.ajax({
                url : 'ajax-function.php?my-model-edit=1',
                type : 'POST',
                data : formData,
                dataType: "json",
                processData: false,  // tell jQuery not to process the data
                contentType: false,  // tell jQuery not to set contentType
                success : function(data) {
                    
                    document.getElementById("preloader").style.display = 'none';
                    document.getElementById("status").style.display = 'none';
                    if(data.status == 'success'){
                        $("#alert-success").append('<p>'+data.msg+'</p>').show();
                        setTimeout(function(){ $("#alert-success").hide(); }, 10000);
                        window.location.href="product-edit.php?id=<?php echo $_REQUEST['id']; ?>";

                    }else if(data.status == 'error'){
                        $("#alert-danger").append('<p>'+data.msg+'</p>').show();
                        
                        setTimeout(function(){ $("#alert-danger").hide(); }, 10000);
                    }else{
                        alert(data);
                    }   
                },
                error: function(jq,status,message) {
                    document.getElementById("preloader").style.display = 'none';
                    document.getElementById("status").style.display = 'none';
                    alert('A jQuery error has occurred. Error:'+ jq.responseText);
                }
            });
        
        }
        
    });
    
</script>
<style>
    input#prod_model_file {
        display: inline-block;
        width: 100%;
        padding: 100px 0 0 0;
        height: 80px;
        overflow: hidden;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        background: url('../public_files/img/698394.png') center center no-repeat #e4e4e4;
        border-radius: 20px;
        background-size: 60px 60px;
    }
    .prod_upload_files, .prod_upload_files_old{
        
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        background:#e4e4e4;
        border-radius: 5px;
    }
	.mb_10 {
		margin-bottom:10px
	}
	.m_0{
		margin:0px
	}
	.p_10 {
		padding:10px
	}
	#preloader {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		opacity: 0.9;
    	background-color: #ffffff;
		z-index: 999999;
	}
	#status {
		width: 200px;
		height: 200px;
		position: absolute;
		left: 50%;
		top: 50%;
		background: url(../public_files/img/1.gif);
		background-repeat: no-repeat;
		background-position: center;
		margin: -100px 0 0 -100px;
	}
</style>

<?php require_once('footer.php'); ?>